<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/assets/css/error403.css">
    <title>Document</title>
</head>
<body>
    <div class="gandalf">
    <div class="fireball"></div>
    <div class="skirt"></div>
    <div class="sleeves"></div>
    <div class="shoulders">
        <div class="hand left"></div>
        <div class="hand right"></div>
    </div>
        <div class="head">
            <div class="hair"></div>
            <div class="beard"></div>
        </div>
    </div>
    <div class="message">
        <h1>403 - Accès interdit</h1>
    </div>
    <a href="/" class="btn-go-home">ACCUEIL</a>
</body>
</html>